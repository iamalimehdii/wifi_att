import 'package:flutter/material.dart';

class MyApp extends StatelessWidget {
  final String description;
  final Widget timer;
  final bool inverted;

  const MyApp({
    required this.description,
    required this.timer,
    this.inverted = false,
    Key? key,
    required String title,
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: FacePage(),
    );
  }
}

class FacePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('FacePage'),
      ),
      body: Center(
        child: Text(
          'Welcome',
          style: TextStyle(
            fontSize: 24.0,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}
